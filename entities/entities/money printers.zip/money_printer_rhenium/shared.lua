ENT.Type 				= "anim"
ENT.Base 				= "base_structure"
ENT.PrintName 			= "Rhenium Money Printer"
ENT.Author 				= "HLTV Proxy"
ENT.Spawnable 			= false
ENT.AdminSpawnable 		= false
ENT.HealthRing			= {450,27,0}
// used by gamemode for power plant
ENT.Power				= 1