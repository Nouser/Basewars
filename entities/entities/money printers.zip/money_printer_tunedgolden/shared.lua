ENT.Type 				= "anim"
ENT.Base 				= "base_structure"
ENT.PrintName 			= "Tuned Golden Money Silo"
ENT.Author 				= "HLTV Proxy"
ENT.Spawnable 			= false
ENT.AdminSpawnable 		= false
ENT.HealthRing			= {2250,60,-25}
// used by gamemode for power plant
ENT.Power				= 5
ENT.SparkPos			= Vector(0,0,40)