ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Tuned Gold Money Printer"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={1350,27,0}
// used by gamemode for power plant
ENT.Power		= 2