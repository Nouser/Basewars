ENT.Type 				= "anim"
ENT.Base 				= "base_structure"
ENT.PrintName 			= "Money Factory"
ENT.Author 				= "HLTV Proxy"
ENT.Spawnable 			= false
ENT.AdminSpawnable 		= false
ENT.HealthRing			= {1350,50,1}
// used by gamemode for power plant
ENT.Power				= 4
ENT.SparkPos			= Vector(20,0,40)