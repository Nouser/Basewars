ENT.Type 				= "anim"
ENT.Base 				= "base_structure"
ENT.PrintName 			= "Nova Money Printer"
ENT.Author 				= "HLTV Proxy"
ENT.Spawnable 			= false
ENT.AdminSpawnable 		= false
ENT.HealthRing			= {3600,70,-30}
// used by gamemode for power plant
ENT.Power				= 7
ENT.SparkPos			= Vector(0,0,40)