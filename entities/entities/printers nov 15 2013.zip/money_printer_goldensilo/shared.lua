ENT.Type 				= "anim"
ENT.Base 				= "base_structure"
ENT.PrintName 			= "Golden Money Silo"
ENT.Author 				= "HLTV Proxy"
ENT.Spawnable 			= false
ENT.AdminSpawnable 		= false
ENT.HealthRing			= {1500,60,-25}
// used by gamemode for power plant
ENT.Power				= 5
ENT.SparkPos			= Vector(0,0,40)