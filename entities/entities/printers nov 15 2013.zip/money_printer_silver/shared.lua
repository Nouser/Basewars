ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Silver Money Printer"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={300,27,0}
// used by gamemode for power plant
ENT.Power		= 1