ENT.Type 				= "anim"
ENT.Base 				= "base_structure"
ENT.PrintName 			= "Nuclear Money Factory"
ENT.Author 				= "HLTV Proxy"
ENT.Spawnable 			= false
ENT.AdminSpawnable 		= false
ENT.HealthRing			= {1650,50,1}
// used by gamemode for power plant
ENT.Power				= 6
ENT.SparkPos			= Vector(20,0,40)